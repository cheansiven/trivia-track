A Pen created at CodePen.io. You can find this one at http://codepen.io/ChynoDeluxe/pen/akamzg.

 A simple jQuery Quiz Plugin that I designed to build for fun. This is my first plugin so feel free to provide some feedback. 